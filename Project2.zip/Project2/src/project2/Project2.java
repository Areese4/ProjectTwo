package project2;
import java.util.*;
import static project2.StepOne.isPalindrome;
import static project2.StepTwo.generateNthLine;

public class Project2 {
    public static void main(String[]args) {
        
        Scanner in = new Scanner(System.in);
        Scanner choose = new Scanner(System.in);
        
        System.out.println("Enter option 1 or 2 to test the function: \n");
        System.out.println("Option 1 will test Palindromes.");
        System.out.println("Option 2 will test Pascal's Triangle. \n");
        System.out.print("You are chosing option: ");
           
        int choice = choose.nextInt();
        boolean a = false;
        
        while(a != true) {
            switch(choice) {
                case 1:
                    System.out.println("You have chose to test Palindromes! \n");
                    System.out.println("Enter a word to check if it's a palindrome.");
                    System.out.println("Enter stop to quit the loop. \n");
                    System.out.print("You're checking the word: ");
                    String x = in.nextLine();

                    if(!"stop".equals(x)) {

                    if(!isPalindrome(x)) {
                        System.out.println("The string " +x+ " is not a palindrome. \n");
                    } else if(isPalindrome(x)) {
                        System.out.println("The string " +x + " is a palindrome. \n");
                        }          
                    } else{
                        a = true;
                    }
                    break;

                case 2:
                    Scanner tri = new Scanner(System.in);
                    System.out.println("You have chose to test Pascal's Triangle! \n");
                    System.out.print("Which line number of Pascal's Triangle? ");

                    int row = tri.nextInt();
                    System.out.print("Line " +row+ " of Pascal's Triangle is: ");
                    generateNthLine(row);
                    a = true;
                    break;
                
                default:
                    System.out.println("Not an option, terminating program. ");
                    a = true;
                    break;
                    
                }
        }
            
    }
}